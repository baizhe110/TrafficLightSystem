/*
 * SensorLightSequence.h
 *
 *  Created on: 1 Oct 2019
 *      Author: bruno
 */

#ifndef SRC_SENSORLIGHTSEQUENCE_H_
#define SRC_SENSORLIGHTSEQUENCE_H_


enum states SensorDrivenLightSequence(void *CurrentState);

void *keyboard(void *notused);


#endif /* SRC_SENSORLIGHTSEQUENCE_H_ */
